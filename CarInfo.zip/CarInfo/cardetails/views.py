from django.shortcuts import render
from .models import Car
# Create your views here.

def index(request):

    car_list=Car.objects.all()
    return render(request, "index.html", {"cars": car_list})