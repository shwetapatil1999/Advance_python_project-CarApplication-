from unittest import result
from django.db import models

# Create your models here.
class Car(models.Model):
    name=models.CharField(max_length=255)
    picture=models.ImageField()
    brand=models.CharField(max_length=250)
    price=models.IntegerField()
    description=models.TextField()

    def __str__(self):
        result=self.name + " by" + self.brand
        return result

    class Meta:
        db_table='car'
