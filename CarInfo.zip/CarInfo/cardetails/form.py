from django import forms
#import model class from models.py
#from app_name.models import model_name
from cardetails.models import  Car

class CarForm(forms.ModelForm):
    class Meta:
        model=Car
        fields="__all__"
